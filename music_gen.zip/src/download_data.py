"""
Download a small public-domain MIDI dataset into data/raw_midi/.

Two sources are supported:

  --dataset classical   Clones a small public GitHub repo of classical piano
                         MIDI files (fast, good for a first run, ~200 files).

  --dataset maestro      Downloads a subset of Google Magenta's MAESTRO
                          v3.0.0 dataset (real piano performances, higher
                          quality, larger download).

Usage:
    python src/download_data.py --dataset classical
    python src/download_data.py --dataset maestro --limit 50
"""

import argparse
import io
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parent.parent
RAW_MIDI_DIR = ROOT / "data" / "raw_midi"

CLASSICAL_REPO = "https://github.com/Skuldur/Classical-Piano-Composer.git"
MAESTRO_ZIP_URL = (
    "https://storage.googleapis.com/magentadata/datasets/maestro/v3.0.0/"
    "maestro-v3.0.0-midi.zip"
)


def download_classical(dest: Path) -> None:
    """Clone a small classical-piano MIDI repo and copy its midi files."""
    print(f"Cloning {CLASSICAL_REPO} ...")
    tmp_dir = ROOT / "_tmp_classical_repo"
    if tmp_dir.exists():
        shutil.rmtree(tmp_dir)

    subprocess.run(
        ["git", "clone", "--depth", "1", CLASSICAL_REPO, str(tmp_dir)],
        check=True,
    )

    midi_src = tmp_dir / "midi_songs"
    if not midi_src.exists():
        # fall back: search the whole repo for .mid files
        midi_src = tmp_dir

    count = 0
    for f in midi_src.rglob("*.mid"):
        shutil.copy(f, dest / f.name)
        count += 1
    for f in midi_src.rglob("*.midi"):
        shutil.copy(f, dest / f.name)
        count += 1

    shutil.rmtree(tmp_dir)
    print(f"Copied {count} MIDI files to {dest}")


def download_maestro(dest: Path, limit: int | None) -> None:
    """Download and unzip a subset of the MAESTRO v3.0.0 dataset."""
    print("Downloading MAESTRO v3.0.0 (this can take a while, ~1.5GB zip)...")
    resp = requests.get(MAESTRO_ZIP_URL, stream=True, timeout=60)
    resp.raise_for_status()

    buf = io.BytesIO()
    for chunk in resp.iter_content(chunk_size=1 << 20):
        buf.write(chunk)
    buf.seek(0)

    print("Extracting .midi files...")
    with zipfile.ZipFile(buf) as zf:
        midi_names = [n for n in zf.namelist() if n.lower().endswith((".mid", ".midi"))]
        if limit:
            midi_names = midi_names[:limit]
        for name in midi_names:
            out_path = dest / Path(name).name
            with zf.open(name) as src, open(out_path, "wb") as out:
                shutil.copyfileobj(src, out)

    print(f"Extracted {len(midi_names)} MIDI files to {dest}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--dataset",
        choices=["classical", "maestro"],
        default="classical",
        help="Which dataset to download.",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Max number of MIDI files to keep (mainly useful for --dataset maestro).",
    )
    args = parser.parse_args()

    RAW_MIDI_DIR.mkdir(parents=True, exist_ok=True)

    if args.dataset == "classical":
        download_classical(RAW_MIDI_DIR)
    else:
        download_maestro(RAW_MIDI_DIR, args.limit)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:  # noqa: BLE001
        print(f"Download failed: {exc}", file=sys.stderr)
        print(
            "You can also just manually place .mid/.midi files into "
            f"{RAW_MIDI_DIR}",
            file=sys.stderr,
        )
        sys.exit(1)
