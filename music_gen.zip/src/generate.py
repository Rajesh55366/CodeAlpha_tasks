"""
Generate a new music sequence from a trained model and save it as a .mid file.

Usage:
    python src/generate.py --model models/final_model.keras --length 500 \
        --output output/generated.mid --temperature 1.0
"""

import argparse
import pickle
from pathlib import Path

import numpy as np
from music21 import chord, instrument, note, stream
from tensorflow import keras

ROOT = Path(__file__).resolve().parent.parent
PROCESSED_DIR = ROOT / "data" / "processed"


def sample_with_temperature(probabilities: np.ndarray, temperature: float) -> int:
    """Temperature-scaled sampling from a softmax distribution."""
    if temperature <= 0:
        return int(np.argmax(probabilities))
    probabilities = np.asarray(probabilities).astype("float64")
    logits = np.log(probabilities + 1e-9) / temperature
    exp_logits = np.exp(logits - np.max(logits))
    scaled = exp_logits / np.sum(exp_logits)
    return int(np.random.choice(len(scaled), p=scaled))


def tokens_to_midi(tokens: list[str], output_path: Path) -> None:
    """Convert a list of 'pitch[.pitch...]_duration' tokens back into a MIDI file."""
    out_stream = stream.Stream()
    out_stream.append(instrument.Piano())

    for tok in tokens:
        pitch_part, duration_part = tok.rsplit("_", 1)
        duration = float(duration_part)
        pitches = pitch_part.split(".")

        if len(pitches) == 1:
            n = note.Note(int(pitches[0]))
            n.quarterLength = duration
            out_stream.append(n)
        else:
            c = chord.Chord([int(p) for p in pitches])
            c.quarterLength = duration
            out_stream.append(c)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    out_stream.write("midi", fp=str(output_path))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=str, default=str(ROOT / "models" / "final_model.keras"))
    parser.add_argument("--vocab", type=str, default=str(PROCESSED_DIR / "vocab.pkl"))
    parser.add_argument("--length", type=int, default=500, help="Number of tokens to generate.")
    parser.add_argument("--temperature", type=float, default=1.0,
                         help="Higher = more random, lower = more conservative/repetitive.")
    parser.add_argument("--output", type=str, default=str(ROOT / "output" / "generated.mid"))
    parser.add_argument("--seed", type=int, default=None, help="Random seed for reproducibility.")
    args = parser.parse_args()

    if args.seed is not None:
        np.random.seed(args.seed)

    model_path = Path(args.model)
    vocab_path = Path(args.vocab)
    if not model_path.exists():
        raise SystemExit(f"Model not found at {model_path}. Run src/train.py first.")
    if not vocab_path.exists():
        raise SystemExit(f"Vocab not found at {vocab_path}. Run src/preprocess.py first.")

    print("Loading model and vocabulary...")
    model = keras.models.load_model(model_path)
    with open(vocab_path, "rb") as fh:
        vocab = pickle.load(fh)
    token_to_int = vocab["token_to_int"]
    int_to_token = vocab["int_to_token"]

    sequence_length = model.input_shape[1]

    # Seed the generation with a random window from real training data if
    # available (gives the model a musically sensible starting context);
    # otherwise fall back to random tokens from the vocabulary.
    seq_path = PROCESSED_DIR / "sequences.npz"
    if seq_path.exists():
        data = np.load(seq_path)
        X = data["X"]
        start_idx = np.random.randint(0, len(X))
        pattern = list(X[start_idx])
    else:
        pattern = list(np.random.randint(0, len(token_to_int), size=sequence_length))

    generated_ids = []
    print(f"Generating {args.length} tokens (temperature={args.temperature})...")
    for _ in range(args.length):
        input_seq = np.array(pattern[-sequence_length:]).reshape(1, sequence_length)
        probabilities = model.predict(input_seq, verbose=0)[0]
        next_id = sample_with_temperature(probabilities, args.temperature)

        generated_ids.append(next_id)
        pattern.append(next_id)

    tokens = [int_to_token[i] for i in generated_ids]

    output_path = Path(args.output)
    tokens_to_midi(tokens, output_path)
    print(f"Saved generated music to {output_path}")


if __name__ == "__main__":
    main()
