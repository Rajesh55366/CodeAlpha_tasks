"""
LSTM model architecture for next-token music generation.

Given a window of SEQUENCE_LENGTH previous tokens, predicts a probability
distribution over the vocabulary for the next token.
"""

from tensorflow import keras
from tensorflow.keras import layers


def build_model(sequence_length: int, vocab_size: int, embedding_dim: int = 100) -> keras.Model:
    """Stacked LSTM with dropout, trained with categorical cross-entropy."""
    model = keras.Sequential(
        [
            layers.Input(shape=(sequence_length,)),
            layers.Embedding(input_dim=vocab_size, output_dim=embedding_dim),
            layers.LSTM(256, return_sequences=True),
            layers.Dropout(0.3),
            layers.LSTM(256),
            layers.Dropout(0.3),
            layers.Dense(256, activation="relu"),
            layers.Dense(vocab_size, activation="softmax"),
        ]
    )

    model.compile(
        loss="sparse_categorical_crossentropy",
        optimizer=keras.optimizers.Adam(learning_rate=1e-3),
        metrics=["accuracy"],
    )
    return model
