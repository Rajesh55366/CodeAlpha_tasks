"""
Preprocess raw MIDI files into fixed-length note-sequence training data.

For every .mid/.midi file in data/raw_midi/, this script:
  1. Parses it with music21 and flattens it to a single stream of events.
  2. Encodes each event as a token: a MIDI pitch number for a single note
     (e.g. "64"), or dot-joined pitch numbers for a chord (e.g. "60.64.67"),
     each combined with its quantized duration (e.g. "64_1.0").
  3. Builds a vocabulary mapping token -> integer id.
  4. Slices the full token sequence per song into overlapping windows of
     length SEQUENCE_LENGTH to build (X, y) training pairs: given the last
     SEQUENCE_LENGTH tokens, predict the next one.

Outputs:
  data/processed/sequences.npz   (X, y arrays, integer-encoded)
  data/processed/vocab.pkl        ({"token_to_int": ..., "int_to_token": ...})
"""

import pickle
from pathlib import Path

import numpy as np
from music21 import chord, converter, note
from tqdm import tqdm

ROOT = Path(__file__).resolve().parent.parent
RAW_MIDI_DIR = ROOT / "data" / "raw_midi"
PROCESSED_DIR = ROOT / "data" / "processed"

SEQUENCE_LENGTH = 100  # how many previous tokens the model sees to predict the next one


def extract_tokens_from_file(midi_path: Path) -> list[str]:
    """Parse one MIDI file and return a flat list of note/chord+duration tokens."""
    tokens: list[str] = []
    try:
        midi_stream = converter.parse(str(midi_path))
    except Exception as exc:  # noqa: BLE001
        print(f"  skipping {midi_path.name} (parse error: {exc})")
        return tokens

    parts = midi_stream.flatten().notes  # notes and chords only, flattened

    for element in parts:
        duration = round(float(element.quarterLength), 2)
        if isinstance(element, note.Note):
            tokens.append(f"{element.pitch.midi}_{duration}")
        elif isinstance(element, chord.Chord):
            pitches = ".".join(str(p.midi) for p in element.pitches)
            tokens.append(f"{pitches}_{duration}")

    return tokens


def build_sequences(all_song_tokens: list[list[str]]):
    """Build vocabulary and (X, y) integer-encoded training windows."""
    vocab = sorted({tok for song in all_song_tokens for tok in song})
    token_to_int = {tok: i for i, tok in enumerate(vocab)}
    int_to_token = {i: tok for tok, i in token_to_int.items()}

    X, y = [], []
    for song_tokens in all_song_tokens:
        encoded = [token_to_int[t] for t in song_tokens]
        if len(encoded) <= SEQUENCE_LENGTH:
            continue
        for i in range(len(encoded) - SEQUENCE_LENGTH):
            X.append(encoded[i : i + SEQUENCE_LENGTH])
            y.append(encoded[i + SEQUENCE_LENGTH])

    return (
        np.array(X, dtype=np.int32),
        np.array(y, dtype=np.int32),
        {"token_to_int": token_to_int, "int_to_token": int_to_token},
    )


def main() -> None:
    midi_files = sorted(list(RAW_MIDI_DIR.glob("*.mid")) + list(RAW_MIDI_DIR.glob("*.midi")))
    if not midi_files:
        raise SystemExit(
            f"No MIDI files found in {RAW_MIDI_DIR}. Run download_data.py first, "
            "or copy your own .mid files there."
        )

    print(f"Found {len(midi_files)} MIDI files. Extracting tokens...")
    all_song_tokens = []
    for f in tqdm(midi_files):
        tokens = extract_tokens_from_file(f)
        if tokens:
            all_song_tokens.append(tokens)

    if not all_song_tokens:
        raise SystemExit("No usable tokens extracted from any MIDI file.")

    print("Building vocabulary and training sequences...")
    X, y, vocab = build_sequences(all_song_tokens)
    print(f"Vocabulary size: {len(vocab['token_to_int'])}")
    print(f"Training examples: {len(X)} (sequence length {SEQUENCE_LENGTH})")

    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    np.savez(PROCESSED_DIR / "sequences.npz", X=X, y=y)
    with open(PROCESSED_DIR / "vocab.pkl", "wb") as fh:
        pickle.dump(vocab, fh)

    print(f"Saved sequences to {PROCESSED_DIR / 'sequences.npz'}")
    print(f"Saved vocabulary to {PROCESSED_DIR / 'vocab.pkl'}")


if __name__ == "__main__":
    main()
