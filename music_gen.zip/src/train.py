"""
Train the LSTM model on preprocessed note sequences.

Usage:
    python src/train.py --epochs 100 --batch-size 64
"""

import argparse
import pickle
from pathlib import Path

import numpy as np
from tensorflow import keras

from model import build_model

ROOT = Path(__file__).resolve().parent.parent
PROCESSED_DIR = ROOT / "data" / "processed"
MODELS_DIR = ROOT / "models"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--val-split", type=float, default=0.1)
    args = parser.parse_args()

    seq_path = PROCESSED_DIR / "sequences.npz"
    vocab_path = PROCESSED_DIR / "vocab.pkl"
    if not seq_path.exists() or not vocab_path.exists():
        raise SystemExit("Run src/preprocess.py first to generate training data.")

    data = np.load(seq_path)
    X, y = data["X"], data["y"]

    with open(vocab_path, "rb") as fh:
        vocab = pickle.load(fh)
    vocab_size = len(vocab["token_to_int"])
    sequence_length = X.shape[1]

    print(f"Loaded {len(X)} training examples, vocab size {vocab_size}, "
          f"sequence length {sequence_length}")

    model = build_model(sequence_length=sequence_length, vocab_size=vocab_size)
    model.summary()

    MODELS_DIR.mkdir(parents=True, exist_ok=True)

    callbacks = [
        keras.callbacks.ModelCheckpoint(
            filepath=str(MODELS_DIR / "checkpoint_epoch{epoch:02d}_loss{loss:.4f}.keras"),
            monitor="loss",
            save_best_only=True,
            verbose=1,
        ),
        keras.callbacks.EarlyStopping(
            monitor="val_loss" if args.val_split > 0 else "loss",
            patience=10,
            restore_best_weights=True,
        ),
        keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss" if args.val_split > 0 else "loss",
            factor=0.5,
            patience=5,
            min_lr=1e-5,
            verbose=1,
        ),
    ]

    model.fit(
        X,
        y,
        epochs=args.epochs,
        batch_size=args.batch_size,
        validation_split=args.val_split,
        callbacks=callbacks,
    )

    final_path = MODELS_DIR / "final_model.keras"
    model.save(final_path)
    print(f"Saved final model to {final_path}")


if __name__ == "__main__":
    main()
